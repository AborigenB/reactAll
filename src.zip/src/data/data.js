const products = [
    {
        id: 0,
        img: 'https://cdn1.ozone.ru/s3/multimedia-g/6820132624.jpg',
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина',
        description: 'aboba',
        price: 335
    },
    {
        id: 1,
        img: 'https://cdn1.ozone.ru/s3/multimedia-1-h/c600/7029631205.jpg',
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина',
        price: 335
    },
    {
        id: 2,
        img: 'https://cdn1.ozone.ru/s3/multimedia-g/6820132624.jpg',
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина',
        price: 335
    },
    {
        id: 3,
        img: 'https://cdn1.ozone.ru/s3/multimedia-1-h/c600/7029631205.jpg',
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина',
        price: 335
    },
    {
        id: 4,
        // img: '',
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина',
        price: 335
    },
    {
        id: 5,
        img: 'https://cdn1.ozone.ru/s3/multimedia-g/6820132624.jpg',
        name: 'Ароматизатор для автомобиля Diamond candle c ароматом "Кожа и древесина',
        price: 335
    },
]

export default products